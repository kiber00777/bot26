# [DownloadMusicBOT]() By Francisco Griman
It is a simple bot that downloads audio from YouTube videos on Telegram.

## Importante!
Faltan algunas cosas por mejorar! Aunque se puede ejecutar con éxito.

## Run
- Clonar este repositorio `git clone https://github.com/fcoagz/DownloadMusicBOT`
- Descarga las dependencias `pip install -r requirements.txt`
- Descarga la biblioteca FFmpeg
- Comience en VS Code o un IDE en línea
- 😎 ¡disfrute!

## Variable de entorno
- `TOKEN in ./configbot.json`: Telegram bot token
- `USER`: Cree un diccionario para el message.text que el usuario enviará (URL)

## Licencia
*MIT: Se permite reutilizar el código. Si quieres contribuir al repositorio, bienvenido <3.*
